# Z01-tools
The elements of computing systems HW - Insper - Tools


# Certificado firebase
export GOOGLE_APPLICATION_CREDENTIALS=/home/corsi/...
